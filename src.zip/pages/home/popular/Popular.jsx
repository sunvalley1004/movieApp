const Popular = () => {
  return <div>Popular</div>;
};

export default Popular;
