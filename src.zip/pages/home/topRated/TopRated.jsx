const TopRated = () => {
  return <div>TopRated</div>;
};

export default TopRated;
